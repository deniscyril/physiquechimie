var SCORM = (function () {
  var api = null;

  function findAPI(win) {
    var tries = 0;
    while (!win.API && win.parent && win.parent !== win && tries < 7) {
      tries++;
      win = win.parent;
    }
    return win.API || null;
  }

  function init() {
    api = findAPI(window);
    if (!api && window.opener) api = findAPI(window.opener);
    if (api) api.LMSInitialize('');
  }

  function reportScore(score, maxScore) {
    if (!api) return;
    api.LMSSetValue('cmi.core.score.raw', String(score));
    api.LMSSetValue('cmi.core.score.min', '0');
    api.LMSSetValue('cmi.core.score.max', String(maxScore));
    api.LMSSetValue('cmi.core.lesson_status', score / maxScore >= 0.5 ? 'passed' : 'failed');
    api.LMSCommit('');
  }

  function finish() { if (api) api.LMSFinish(''); }

  window.addEventListener('load', init);
  window.addEventListener('beforeunload', finish);

  return { reportScore: reportScore };
})();
